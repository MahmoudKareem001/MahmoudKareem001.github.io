let orders=1200,profit=45000,customers=850;
const names=['Ahmad','Sara','Omar','Lina','Ali','Noor'];
function update(){
orders+=Math.floor(Math.random()*5)+1;
profit+=Math.floor(Math.random()*100)+20;
customers+=Math.floor(Math.random()*2);
document.getElementById('orders').innerText=orders;
document.getElementById('profit').innerText=profit+' JOD';
document.getElementById('customers').innerText=customers;
const row=document.createElement('tr');
row.innerHTML=`<td>#${orders}</td><td>${names[Math.floor(Math.random()*names.length)]}</td><td>${Math.floor(Math.random()*200)+10} JOD</td>`;
const t=document.getElementById('ordersTable');
t.prepend(row);
if(t.rows.length>10)t.deleteRow(10);
}
setInterval(update,3000);
update();
